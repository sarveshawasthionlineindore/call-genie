import json
import logging
import httpx
from typing import List, Dict, Any
from app.config import settings

logger = logging.getLogger("knowledge_service")


class KnowledgeService:
    @staticmethod
    async def extract_voice_friendly_qa(raw_text: str, business_name: str) -> List[Dict[str, str]]:
        """
        Uses Groq LLM to summarize raw documents, PDFs, or brochures into
        ultra-crisp, voice-friendly Q&A pairs suitable for realtime calling (<200ms).
        """
        if not raw_text or len(raw_text.strip()) < 20:
            return []

        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {settings.GROQ_API_KEY}",
            "Content-Type": "application/json"
        }

        system_instruction = (
            f"You are a Knowledge Engineer preparing a Knowledge Base for a telephone AI voice agent of '{business_name}'.\n"
            "Extract the most important facts, prices, timings, services, and rules from the provided text.\n"
            "Return valid JSON array of objects with keys 'question' and 'answer':\n"
            "[\n"
            '  {"question": "What is the pricing/rate?", "answer": "1-2 sentence direct spoken answer"},\n'
            '  {"question": "Where is the location?", "answer": "1-2 sentence direct spoken answer"}\n'
            "]\n"
            "Rules:\n"
            "1. Answers must be very short, natural for speaking over phone in Hindi or Hinglish.\n"
            "2. Never make up facts outside the provided text."
        )

        payload = {
            "model": "llama-3.1-8b-instant",
            "messages": [
                {"role": "system", "content": system_instruction},
                {"role": "user", "content": f"Business Knowledge Document:\n{raw_text[:6000]}"}
            ],
            "temperature": 0.2,
            "response_format": {"type": "json_object"}
        }

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.post(url, headers=headers, json=payload)
                if resp.status_code == 200:
                    data = resp.json()
                    content = data["choices"][0]["message"]["content"]
                    parsed = json.loads(content)
                    if isinstance(parsed, dict) and "qa" in parsed:
                        return parsed["qa"]
                    elif isinstance(parsed, list):
                        return parsed
                    elif isinstance(parsed, dict) and len(parsed) > 0:
                        # Find list values
                        for val in parsed.values():
                            if isinstance(val, list):
                                return val
        except Exception as e:
            logger.error(f"Error extracting voice QA: {str(e)}")

        return []

    @staticmethod
    def compile_knowledge_for_prompt(docs: list) -> str:
        """
        Formats all active knowledge documents into a prompt-friendly factsheet.
        """
        if not docs:
            return ""

        sections = ["### VERIFIED BUSINESS KNOWLEDGE (Stick strictly to these facts):"]
        for doc in docs:
            sections.append(f"\nSource: {doc.title}")
            if doc.structured_qa and isinstance(doc.structured_qa, list):
                for item in doc.structured_qa:
                    q = item.get("question", "")
                    a = item.get("answer", "")
                    sections.append(f"- Q: {q}\n  A: {a}")
            elif doc.raw_content:
                sections.append(doc.raw_content[:1500])

        return "\n".join(sections)
