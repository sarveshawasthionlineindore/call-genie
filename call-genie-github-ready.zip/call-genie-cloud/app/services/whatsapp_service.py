import httpx
import logging
from typing import Optional
from app.config import settings

logger = logging.getLogger("whatsapp_service")


class WhatsAppService:
    @staticmethod
    def _clean_phone_number(phone: str) -> str:
        """
        Cleans phone number and formats with 91 country code for India.
        """
        digits = "".join(filter(str.isdigit, phone))
        if len(digits) == 10:
            return f"91{digits}"
        if digits.startswith("0") and len(digits) == 11:
            return f"91{digits[1:]}"
        return digits

    @staticmethod
    async def send_post_call_message(
        phone_number: str,
        message_text: Optional[str] = None,
        template_name: Optional[str] = None,
        template_components: Optional[list] = None
    ) -> bool:
        """
        Sends post-call WhatsApp follow-up via Meta Cloud API or MyBot Genie WhatsApp gateway.
        """
        if not settings.WHATSAPP_TOKEN or not settings.WHATSAPP_PHONE_NUMBER_ID:
            logger.warning("WhatsApp credentials not set in environment. Skipping message delivery.")
            return False

        clean_number = WhatsAppService._clean_phone_number(phone_number)
        url = f"https://graph.facebook.com/v20.0/{settings.WHATSAPP_PHONE_NUMBER_ID}/messages"
        headers = {
            "Authorization": f"Bearer {settings.WHATSAPP_TOKEN}",
            "Content-Type": "application/json"
        }

        if template_name:
            payload = {
                "messaging_product": "whatsapp",
                "to": clean_number,
                "type": "template",
                "template": {
                    "name": template_name,
                    "language": {"code": "en"},
                    "components": template_components or []
                }
            }
        else:
            text_body = message_text or (
                "Namaste! Thank you for speaking with our Call Genie AI assistant. "
                "Here are the details we discussed. Feel free to reply to this chat if you have any questions!"
            )
            payload = {
                "messaging_product": "whatsapp",
                "recipient_type": "individual",
                "to": clean_number,
                "type": "text",
                "text": {"preview_url": True, "body": text_body}
            }

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(url, headers=headers, json=payload)
                if response.status_code in [200, 201]:
                    logger.info(f"WhatsApp sent successfully to {clean_number}")
                    return True
                else:
                    logger.error(f"WhatsApp API error ({response.status_code}): {response.text}")
                    return False
        except Exception as e:
            logger.error(f"Failed to deliver WhatsApp message: {str(e)}")
            return False
