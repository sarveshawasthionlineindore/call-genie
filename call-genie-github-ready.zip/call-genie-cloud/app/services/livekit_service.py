import logging
import uuid
from typing import Optional, Dict, Any
from livekit import api
from sqlalchemy import select
from app.config import settings
from app.database import AsyncSessionLocal
from app.models import Agent, KnowledgeDocument
from app.services.knowledge_service import KnowledgeService

logger = logging.getLogger("livekit_service")


class LiveKitService:
    @staticmethod
    def get_api_client() -> api.LiveKitAPI:
        return api.LiveKitAPI(
            url=settings.LIVEKIT_URL,
            api_key=settings.LIVEKIT_API_KEY,
            api_secret=settings.LIVEKIT_API_SECRET
        )

    @staticmethod
    async def create_outbound_call(
        phone_number: str,
        agent_id: str,
        tenant_id: str,
        custom_metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Creates a dedicated LiveKit room, automatically injecting the agent's
        custom Knowledge Base & structured FAQs into the LLM system prompt.
        """
        room_name = f"call_{tenant_id[:8]}_{uuid.uuid4().hex[:8]}"
        livekit_client = LiveKitService.get_api_client()

        # Fetch Agent & its Knowledge Base from database
        system_prompt = "You are an AI assistant for Call Genie (by MyBot Genie)."
        first_message = "Namaste! Main Call Genie AI se baat kar raha hoon."
        language = "hi-IN"

        async with AsyncSessionLocal() as db:
            agent_stmt = select(Agent).where(Agent.id == agent_id)
            agent = (await db.execute(agent_stmt)).scalar_one_or_none()
            if agent:
                system_prompt = agent.system_prompt
                first_message = agent.first_message
                language = agent.language

                # Fetch all verified knowledge documents attached to this agent
                k_stmt = select(KnowledgeDocument).where(
                    KnowledgeDocument.agent_id == agent.id,
                    KnowledgeDocument.is_active == True
                )
                k_docs = (await db.execute(k_stmt)).scalars().all()
                if k_docs:
                    knowledge_context = KnowledgeService.compile_knowledge_for_prompt(k_docs)
                    system_prompt = f"{system_prompt}\n\n{knowledge_context}"

        metadata_dict = {
            "tenant_id": tenant_id,
            "agent_id": agent_id,
            "phone_number": phone_number,
            "system_prompt": custom_metadata.get("system_prompt", system_prompt) if custom_metadata else system_prompt,
            "first_message": custom_metadata.get("first_message", first_message) if custom_metadata else first_message,
            "language": custom_metadata.get("language", language) if custom_metadata else language,
            **(custom_metadata or {})
        }

        try:
            # 1. Create the LiveKit Room for audio streaming
            await livekit_client.room.create_room(
                api.CreateRoomRequest(
                    name=room_name,
                    empty_timeout=300,
                    max_participants=2,
                    metadata=str(metadata_dict)
                )
            )

            # 2. Trigger SIP Outbound participant if SIP trunk is configured
            if settings.SIP_TRUNK_ID:
                try:
                    await livekit_client.sip.create_sip_participant(
                        api.CreateSIPParticipantRequest(
                            sip_trunk_id=settings.SIP_TRUNK_ID,
                            sip_call_to=phone_number,
                            room_name=room_name,
                            participant_identity=f"phone_{phone_number}",
                            participant_name="Customer",
                        )
                    )
                    logger.info(f"SIP participant dispatched for {phone_number} in room {room_name}")
                except Exception as sip_err:
                    logger.warning(f"SIP bridge returned: {sip_err}.")

            await livekit_client.aclose()
            return room_name
        except Exception as e:
            logger.error(f"Error creating LiveKit room for outbound call: {str(e)}")
            await livekit_client.aclose()
            return room_name
