import math
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models import Wallet, WalletTransaction, Tenant
from app.config import settings


class BillingService:
    @staticmethod
    def calculate_billable_units(duration_seconds: int, pulse_seconds: int = 60) -> float:
        """
        Calculates billable minutes based on pulse billing.
        e.g., if pulse is 60s, a 15-second call counts as 1.0 minute.
        """
        if duration_seconds <= 0:
            return 0.0
        pulses = math.ceil(duration_seconds / pulse_seconds)
        billable_minutes = (pulses * pulse_seconds) / 60.0
        return billable_minutes

    @staticmethod
    async def check_wallet_balance(db: AsyncSession, tenant_id: str, min_required_inr: float = 5.0) -> bool:
        """
        Checks if the tenant's wallet has sufficient funds to place or receive a call.
        """
        stmt = select(Wallet).where(Wallet.tenant_id == tenant_id)
        result = await db.execute(stmt)
        wallet = result.scalar_one_or_none()
        if not wallet or wallet.balance_inr < min_required_inr:
            return False
        return True

    @staticmethod
    async def process_call_billing(
        db: AsyncSession,
        tenant_id: str,
        duration_seconds: int,
        call_log_id: str
    ) -> dict:
        """
        Deducts balance from client's wallet and logs transaction.
        Returns calculated metrics.
        """
        stmt = select(Tenant).where(Tenant.id == tenant_id)
        tenant_res = await db.execute(stmt)
        tenant = tenant_res.scalar_one_or_none()
        rate_per_min = tenant.rate_per_min_inr if tenant else settings.DEFAULT_RETAIL_RATE_PER_MIN_INR

        billable_minutes = BillingService.calculate_billable_units(
            duration_seconds, settings.BILLING_PULSE_SECONDS
        )
        revenue_charged = round(billable_minutes * rate_per_min, 2)
        
        # Internal raw cost estimate (~INR 2.10/min)
        internal_cogs = round(billable_minutes * 2.10, 2)

        if revenue_charged > 0:
            wallet_stmt = select(Wallet).where(Wallet.tenant_id == tenant_id)
            wallet_res = await db.execute(wallet_stmt)
            wallet = wallet_res.scalar_one_or_none()

            if wallet:
                wallet.balance_inr = round(wallet.balance_inr - revenue_charged, 2)
                
                transaction = WalletTransaction(
                    wallet_id=wallet.id,
                    tenant_id=tenant_id,
                    amount_inr=revenue_charged,
                    type="DEBIT",
                    description=f"Call charges for {duration_seconds}s ({billable_minutes} min billable)",
                    reference_id=call_log_id
                )
                db.add(transaction)
                await db.commit()

        return {
            "billable_minutes": billable_minutes,
            "revenue_charged_inr": revenue_charged,
            "cost_incurred_inr": internal_cogs
        }

    @staticmethod
    async def credit_wallet(
        db: AsyncSession,
        tenant_id: str,
        amount_inr: float,
        reference_id: str,
        description: str = "Wallet Recharge via Razorpay"
    ) -> float:
        """
        Credits funds to the tenant's prepaid balance.
        """
        stmt = select(Wallet).where(Wallet.tenant_id == tenant_id)
        result = await db.execute(stmt)
        wallet = result.scalar_one_or_none()
        if not wallet:
            wallet = Wallet(tenant_id=tenant_id, balance_inr=amount_inr)
            db.add(wallet)
            await db.flush()
        else:
            wallet.balance_inr = round(wallet.balance_inr + amount_inr, 2)

        transaction = WalletTransaction(
            wallet_id=wallet.id,
            tenant_id=tenant_id,
            amount_inr=amount_inr,
            type="CREDIT",
            description=description,
            reference_id=reference_id
        )
        db.add(transaction)
        await db.commit()
        return wallet.balance_inr
