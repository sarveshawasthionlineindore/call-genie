from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List
from app.database import get_db
from app.models import Agent, User
from app.schemas import AgentCreate, AgentUpdate, AgentOut
from app.routers.auth import get_current_user

router = APIRouter(prefix="/api/agents", tags=["Agent Studio"])


@router.post("", response_model=AgentOut)
async def create_agent(
    agent_in: AgentCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    agent = Agent(
        tenant_id=current_user.tenant_id,
        name=agent_in.name,
        system_prompt=agent_in.system_prompt,
        first_message=agent_in.first_message,
        voice_provider=agent_in.voice_provider or "sarvam",
        voice_id=agent_in.voice_id or "bulbul:v1",
        language=agent_in.language or "hi-IN",
        temperature=agent_in.temperature or 0.7,
        inbound_phone_number=agent_in.inbound_phone_number,
        post_call_whatsapp_enabled=agent_in.post_call_whatsapp_enabled if agent_in.post_call_whatsapp_enabled is not None else True,
        whatsapp_template_name=agent_in.whatsapp_template_name,
        whatsapp_followup_message=agent_in.whatsapp_followup_message
    )
    db.add(agent)
    await db.commit()
    await db.refresh(agent)
    return agent


@router.get("", response_model=List[AgentOut])
async def list_agents(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    stmt = select(Agent).where(Agent.tenant_id == current_user.tenant_id).order_by(Agent.created_at.desc())
    result = await db.execute(stmt)
    return result.scalars().all()


@router.get("/{agent_id}", response_model=AgentOut)
async def get_agent(
    agent_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    stmt = select(Agent).where(Agent.id == agent_id, Agent.tenant_id == current_user.tenant_id)
    agent = (await db.execute(stmt)).scalar_one_or_none()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agent


@router.put("/{agent_id}", response_model=AgentOut)
async def update_agent(
    agent_id: str,
    agent_in: AgentUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    stmt = select(Agent).where(Agent.id == agent_id, Agent.tenant_id == current_user.tenant_id)
    agent = (await db.execute(stmt)).scalar_one_or_none()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    update_data = agent_in.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(agent, field, value)

    await db.commit()
    await db.refresh(agent)
    return agent


@router.delete("/{agent_id}")
async def delete_agent(
    agent_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    stmt = select(Agent).where(Agent.id == agent_id, Agent.tenant_id == current_user.tenant_id)
    agent = (await db.execute(stmt)).scalar_one_or_none()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    await db.delete(agent)
    await db.commit()
    return {"message": "Agent deleted successfully"}
