from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import datetime, timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext
from app.database import get_db
from app.models import User, Tenant, Wallet
from app.schemas import UserRegister, UserLogin, TokenResponse
from app.config import settings

router = APIRouter(prefix="/api/auth", tags=["Authentication"])

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")


def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password):
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


async def get_current_user(token: str = Depends(oauth2_scheme), db: AsyncSession = Depends(get_db)) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    stmt = select(User).where(User.id == user_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    if user is None:
        raise credentials_exception
    return user


@router.post("/register", response_model=TokenResponse)
async def register(user_in: UserRegister, db: AsyncSession = Depends(get_db)):
    # Check if user already exists
    stmt = select(User).where(User.email == user_in.email)
    existing_user = (await db.execute(stmt)).scalar_one_or_none()
    if existing_user:
        raise HTTPException(status_code=400, detail="User with this email already exists")

    # 1. Create Tenant (Organization)
    tenant = Tenant(
        name=user_in.company_name,
        rate_per_min_inr=settings.DEFAULT_RETAIL_RATE_PER_MIN_INR
    )
    db.add(tenant)
    await db.flush()

    # 2. Create User
    hashed_password = get_password_hash(user_in.password)
    new_user = User(
        tenant_id=tenant.id,
        email=user_in.email,
        hashed_password=hashed_password,
        full_name=user_in.full_name,
        role="admin"
    )
    db.add(new_user)

    # 3. Create initial Wallet with bonus credits for testing
    wallet = Wallet(tenant_id=tenant.id, balance_inr=100.0)
    db.add(wallet)

    await db.commit()
    await db.refresh(new_user)

    access_token = create_access_token(data={"sub": new_user.id, "tenant_id": tenant.id})
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "tenant_id": tenant.id,
        "email": new_user.email,
        "company_name": tenant.name
    }


@router.post("/login", response_model=TokenResponse)
async def login(user_in: UserLogin, db: AsyncSession = Depends(get_db)):
    stmt = select(User).where(User.email == user_in.email)
    user = (await db.execute(stmt)).scalar_one_or_none()
    if not user or not verify_password(user_in.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect email or password")

    tenant_stmt = select(Tenant).where(Tenant.id == user.tenant_id)
    tenant = (await db.execute(tenant_stmt)).scalar_one_or_none()

    access_token = create_access_token(data={"sub": user.id, "tenant_id": user.tenant_id})
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "tenant_id": user.tenant_id,
        "email": user.email,
        "company_name": tenant.name if tenant else "MyBot Genie Client"
    }
