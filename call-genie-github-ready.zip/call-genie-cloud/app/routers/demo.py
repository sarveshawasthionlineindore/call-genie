import logging
from pydantic import BaseModel
from typing import Optional
from fastapi import APIRouter, HTTPException, BackgroundTasks
import httpx
import os
import json
from app.services.livekit_service import LiveKitService
from app.services.whatsapp_service import WhatsAppService
from app.config import settings

logger = logging.getLogger("demo_router")
router = APIRouter(prefix="/api/demo", tags=["Personalized Live Demo"])


class PersonalizedDemoRequest(BaseModel):
    client_name: str
    business_name: str
    business_type: str  # Real Estate, Clinic, Coaching, Finance, E-commerce, etc.
    phone_number: str
    language: Optional[str] = "hi-IN"


def generate_personalized_system_prompt(name: str, business: str, category: str) -> dict:
    """
    Dynamically generates a customized persona where Call Genie acts as the business owner's
    very own AI receptionist or sales caller during the demo call.
    """
    first_message = (
        f"Namaste {name} ji! Main Call Genie AI bol raha hoon from MyBot Genie. "
        f"Imagine kijiye agar koi naya customer {business} par call kare, "
        f"toh main theek isi tarah bina kisi staff ke unka phone utha sakta hoon! "
        f"Kya aap dekhna chahenge ki main {business} ke liye kaise leads book karta hoon?"
    )

    system_prompt = (
        f"You are Call Genie, an intelligent voice AI assistant demonstrating your capabilities live to {name}, "
        f"who runs a business named '{business}' in the '{category}' industry in India.\n"
        f"Goal: Show {name} how you can be an outstanding AI telecaller/receptionist for {business}.\n"
        f"Style & Tone:\n"
        f"- Speak natural, warm Hindi and Hinglish with an authentic Indian accent.\n"
        f"- Be concise (1-2 sentences per turn), polite, and professional.\n"
        f"- Demonstrate that you understand their industry ({category}). If they ask questions about their business, answer smartly.\n"
        f"- Highlight that you cost only ₹4 to ₹5 per minute, work 24/7 without leaves, and send instant WhatsApp brochures.\n"
        f"- At the end of the call, tell them: 'Main aapke isi number par WhatsApp par details bhej raha hoon, dhanyawad!'"
    )

    return {
        "first_message": first_message,
        "system_prompt": system_prompt
    }


async def execute_demo_call_task(req: PersonalizedDemoRequest):
    prompt_config = generate_personalized_system_prompt(
        name=req.client_name,
        business=req.business_name,
        category=req.business_type
    )

    # Trigger LiveKit Outbound Call with dynamically crafted prompt in metadata
    room_name = await LiveKitService.create_outbound_call(
        phone_number=req.phone_number,
        agent_id="demo_agent",
        tenant_id="public_demo",
        custom_metadata={
            "is_demo": True,
            "client_name": req.client_name,
            "business_name": req.business_name,
            "business_type": req.business_type,
            "system_prompt": prompt_config["system_prompt"],
            "first_message": prompt_config["first_message"],
            "language": req.language
        }
    )
    logger.info(f"Triggered personalized demo call for {req.business_name} ({req.phone_number}) in room {room_name}")


@router.post("/personalized-call")
async def request_personalized_demo_call(
    demo_in: PersonalizedDemoRequest,
    background_tasks: BackgroundTasks
):
    """
    Public API endpoint: Takes business details and dials the client in 5 seconds
    with a fully customized conversational AI persona tailored to their business.
    """
    clean_phone = demo_in.phone_number.strip().replace(" ", "").replace("-", "")
    if len(clean_phone) < 10:
        raise HTTPException(status_code=400, detail="Please provide a valid 10-digit mobile number")

    background_tasks.add_task(execute_demo_call_task, demo_in)

    return {
        "status": "initiated",
        "message": f"Demo call scheduled in 5 seconds for {demo_in.business_name}",
        "phone_number": clean_phone,
        "first_message_preview": (
            f"Namaste {demo_in.client_name} ji! Main Call Genie AI bol raha hoon. "
            f"Imagine kijiye agar koi customer {demo_in.business_name} par call kare..."
        )
    }
