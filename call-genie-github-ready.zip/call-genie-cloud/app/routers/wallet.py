from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from typing import List
from app.database import get_db
from app.models import Wallet, WalletTransaction, Tenant, User
from app.schemas import WalletOut, WalletRechargeRequest, TransactionOut
from app.routers.auth import get_current_user
from app.services.billing_service import BillingService

router = APIRouter(prefix="/api/wallet", tags=["Wallet & Billing"])


@router.get("", response_model=WalletOut)
async def get_wallet(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    stmt = select(Wallet).where(Wallet.tenant_id == current_user.tenant_id)
    wallet = (await db.execute(stmt)).scalar_one_or_none()
    
    tenant_stmt = select(Tenant).where(Tenant.id == current_user.tenant_id)
    tenant = (await db.execute(tenant_stmt)).scalar_one_or_none()

    if not wallet:
        wallet = Wallet(tenant_id=current_user.tenant_id, balance_inr=0.0)
        db.add(wallet)
        await db.commit()
        await db.refresh(wallet)

    return {
        "balance_inr": wallet.balance_inr,
        "currency": wallet.currency,
        "rate_per_min_inr": tenant.rate_per_min_inr if tenant else 5.00
    }


@router.get("/transactions", response_model=List[TransactionOut])
async def get_transactions(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    stmt = select(WalletTransaction).where(
        WalletTransaction.tenant_id == current_user.tenant_id
    ).order_by(desc(WalletTransaction.created_at)).limit(100)
    
    result = await db.execute(stmt)
    return result.scalars().all()


@router.post("/recharge", response_model=dict)
async def recharge_wallet(
    recharge_in: WalletRechargeRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Credits money to wallet after payment confirmation.
    """
    if recharge_in.amount_inr <= 0:
        raise HTTPException(status_code=400, detail="Recharge amount must be greater than zero")

    new_balance = await BillingService.credit_wallet(
        db=db,
        tenant_id=current_user.tenant_id,
        amount_inr=recharge_in.amount_inr,
        reference_id=recharge_in.payment_reference,
        description=f"Prepaid wallet recharge of ₹{recharge_in.amount_inr}"
    )

    return {
        "message": f"Successfully recharged ₹{recharge_in.amount_inr}",
        "new_balance_inr": new_balance
    }
