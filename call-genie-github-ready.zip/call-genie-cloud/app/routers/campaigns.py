import io
import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List
from app.database import get_db, AsyncSessionLocal
from app.models import Campaign, Contact, Agent, User, CallLog
from app.schemas import CampaignCreate, SingleCallRequest
from app.routers.auth import get_current_user
from app.services.billing_service import BillingService
from app.services.livekit_service import LiveKitService

router = APIRouter(prefix="/api/campaigns", tags=["Outbound Campaigns & Dialer"])


async def dial_contact_task(campaign_id: str, contact_id: str, tenant_id: str, agent_id: str, phone: str):
    """
    Background worker that checks wallet, initiates LiveKit room, and updates contact status.
    """
    async with AsyncSessionLocal() as db:
        # Check wallet before placing call
        has_balance = await BillingService.check_wallet_balance(db, tenant_id, min_required_inr=5.0)
        stmt = select(Contact).where(Contact.id == contact_id)
        contact = (await db.execute(stmt)).scalar_one_or_none()
        if not contact:
            return

        if not has_balance:
            contact.status = "FAILED"
            contact.custom_data = {**(contact.custom_data or {}), "error": "Insufficient wallet balance"}
            await db.commit()
            return

        contact.status = "CALLING"
        await db.commit()

        # Trigger LiveKit outbound call
        room_name = await LiveKitService.create_outbound_call(
            phone_number=phone,
            agent_id=agent_id,
            tenant_id=tenant_id,
            custom_metadata={"campaign_id": campaign_id, "contact_id": contact_id}
        )

        contact.call_id = room_name

        # Create initial CallLog
        call_log = CallLog(
            tenant_id=tenant_id,
            agent_id=agent_id,
            campaign_id=campaign_id,
            contact_id=contact_id,
            room_name=room_name,
            receiver_number=phone,
            direction="OUTBOUND",
            status="INITIATED"
        )
        db.add(call_log)
        await db.commit()


@router.post("", response_model=dict)
async def create_campaign(
    campaign_in: CampaignCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # Verify agent exists
    agent_stmt = select(Agent).where(Agent.id == campaign_in.agent_id, Agent.tenant_id == current_user.tenant_id)
    agent = (await db.execute(agent_stmt)).scalar_one_or_none()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    campaign = Campaign(
        tenant_id=current_user.tenant_id,
        agent_id=campaign_in.agent_id,
        name=campaign_in.name,
        concurrency_limit=campaign_in.concurrency_limit or 1,
        status="DRAFT"
    )
    db.add(campaign)
    await db.commit()
    await db.refresh(campaign)
    return {"campaign_id": campaign.id, "name": campaign.name, "status": campaign.status}


@router.post("/{campaign_id}/upload-csv")
async def upload_campaign_csv(
    campaign_id: str,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    stmt = select(Campaign).where(Campaign.id == campaign_id, Campaign.tenant_id == current_user.tenant_id)
    campaign = (await db.execute(stmt)).scalar_one_or_none()
    if not campaign:
        raise HTTPException(status_code=404, detail="Campaign not found")

    contents = await file.read()
    try:
        df = pd.read_csv(io.BytesIO(contents))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid CSV file format: {str(e)}")

    # Detect phone column
    phone_col = None
    for col in df.columns:
        if "phone" in col.lower() or "mobile" in col.lower() or "number" in col.lower() or "contact" in col.lower():
            phone_col = col
            break

    if not phone_col:
        phone_col = df.columns[0]  # default to first column

    name_col = None
    for col in df.columns:
        if "name" in col.lower():
            name_col = col
            break

    contacts_to_add = []
    for _, row in df.iterrows():
        raw_phone = str(row[phone_col]).strip()
        if not raw_phone or raw_phone.lower() == "nan":
            continue
        cust_name = str(row[name_col]).strip() if name_col and not pd.isna(row[name_col]) else None
        
        contact = Contact(
            campaign_id=campaign.id,
            phone_number=raw_phone,
            name=cust_name,
            custom_data=row.to_dict(),
            status="PENDING"
        )
        contacts_to_add.append(contact)

    db.add_all(contacts_to_add)
    campaign.total_contacts += len(contacts_to_add)
    await db.commit()

    return {
        "message": f"Successfully imported {len(contacts_to_add)} contacts",
        "total_contacts": campaign.total_contacts
    }


@router.post("/{campaign_id}/start")
async def start_campaign(
    campaign_id: str,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # Verify wallet has funds
    has_funds = await BillingService.check_wallet_balance(db, current_user.tenant_id, min_required_inr=10.0)
    if not has_funds:
        raise HTTPException(status_code=402, detail="Insufficient wallet balance. Please recharge wallet before starting campaign.")

    stmt = select(Campaign).where(Campaign.id == campaign_id, Campaign.tenant_id == current_user.tenant_id)
    campaign = (await db.execute(stmt)).scalar_one_or_none()
    if not campaign:
        raise HTTPException(status_code=404, detail="Campaign not found")

    campaign.status = "RUNNING"
    await db.commit()

    # Get pending contacts
    contact_stmt = select(Contact).where(Contact.campaign_id == campaign_id, Contact.status == "PENDING")
    contacts = (await db.execute(contact_stmt)).scalars().all()

    for contact in contacts:
        background_tasks.add_task(
            dial_contact_task,
            campaign_id=campaign.id,
            contact_id=contact.id,
            tenant_id=current_user.tenant_id,
            agent_id=campaign.agent_id,
            phone=contact.phone_number
        )

    return {"message": f"Campaign started with {len(contacts)} contacts queued for dialing", "status": "RUNNING"}


@router.post("/single-call")
async def place_single_call(
    call_req: SingleCallRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Triggers an instant single outbound call to test an agent.
    """
    has_funds = await BillingService.check_wallet_balance(db, current_user.tenant_id, min_required_inr=5.0)
    if not has_funds:
        raise HTTPException(status_code=402, detail="Insufficient wallet balance. Minimum balance required is ₹5.00")

    agent_stmt = select(Agent).where(Agent.id == call_req.agent_id, Agent.tenant_id == current_user.tenant_id)
    agent = (await db.execute(agent_stmt)).scalar_one_or_none()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    room_name = await LiveKitService.create_outbound_call(
        phone_number=call_req.phone_number,
        agent_id=call_req.agent_id,
        tenant_id=current_user.tenant_id,
        custom_metadata={"customer_name": call_req.customer_name, **(call_req.custom_variables or {})}
    )

    call_log = CallLog(
        tenant_id=current_user.tenant_id,
        agent_id=agent.id,
        room_name=room_name,
        receiver_number=call_req.phone_number,
        direction="OUTBOUND",
        status="INITIATED"
    )
    db.add(call_log)
    await db.commit()

    return {"message": "Call initiated successfully", "room_name": room_name, "phone_number": call_req.phone_number}
