import logging
import httpx
import json
from pydantic import BaseModel
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import Tenant, User, Agent, KnowledgeDocument
from app.routers.auth import get_current_user
from app.services.knowledge_service import KnowledgeService
from app.services.livekit_service import LiveKitService
from app.config import settings

logger = logging.getLogger("onboarding")
router = APIRouter(prefix="/api/onboarding", tags=["Client Onboarding Wizard"])


class OnboardingWizardRequest(BaseModel):
    company_name: str
    industry: str  # Real Estate, Clinic, Coaching, Finance, E-commerce, Local Services
    business_description: str
    knowledge_raw_text: Optional[str] = None  # Pricing, services, policies, FAQ
    whatsapp_followup_link: Optional[str] = None
    voice_preference: Optional[str] = "sarvam"  # sarvam, cartesia
    language: Optional[str] = "hi-IN"
    phone_number_for_test_call: Optional[str] = None


async def trigger_onboarding_verification_call(
    phone_number: str,
    agent_id: str,
    tenant_id: str,
    company_name: str
):
    try:
        await LiveKitService.create_outbound_call(
            phone_number=phone_number,
            agent_id=agent_id,
            tenant_id=tenant_id,
            custom_metadata={
                "is_onboarding_test": True,
                "company_name": company_name
            }
        )
        logger.info(f"Onboarding verification call placed to {phone_number}")
    except Exception as e:
        logger.error(f"Failed to place onboarding verification call: {str(e)}")


@router.post("/wizard")
async def complete_onboarding_wizard(
    wizard_in: OnboardingWizardRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Automated 5-in-1 Client Onboarding:
    1. Updates Company Profile & Industry.
    2. Auto-synthesizes optimized Agent Prompt & First Message via Groq LLM.
    3. Builds and attaches the structured Knowledge Base to the Agent.
    4. Sets up WhatsApp brochure delivery hook.
    5. Triggers an instant live verification call to the client's phone!
    """
    tenant_stmt = select(Tenant).where(Tenant.id == current_user.tenant_id)
    tenant = (await db.execute(tenant_stmt)).scalar_one_or_none()
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")

    tenant.name = wizard_in.company_name
    tenant.industry = wizard_in.industry
    tenant.onboarding_completed = True

    # 1. Use Groq to automatically design the agent's prompt based on the client's business & knowledge
    llm_url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {settings.GROQ_API_KEY}",
        "Content-Type": "application/json"
    }

    prompt_builder_query = (
        f"Design the ultimate system prompt and first greeting for an AI voice caller.\n"
        f"Company: '{wizard_in.company_name}'\n"
        f"Industry: '{wizard_in.industry}'\n"
        f"About: '{wizard_in.business_description}'\n"
        f"Knowledge / Offerings: '{wizard_in.knowledge_raw_text or 'General inquiries and bookings'}'\n\n"
        "Return valid JSON only:\n"
        "{\n"
        '  "agent_name": "Short name for agent",\n'
        '  "first_message": "Friendly greeting in natural Hindi/Hinglish (under 25 words)",\n'
        '  "system_prompt": "Detailed persona instructions, tone, objection handling, and pricing rules (under 200 words)"\n'
        "}"
    )

    agent_name = f"{wizard_in.company_name} AI Receptionist"
    first_message = f"Namaste! Main {wizard_in.company_name} se baat kar raha hoon. Kya main aapki koi madad kar sakta hoon?"
    system_prompt = f"You are the official AI assistant for {wizard_in.company_name} ({wizard_in.industry}). Speak naturally in Hindi and Hinglish."

    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(
                llm_url,
                headers=headers,
                json={
                    "model": "llama-3.1-8b-instant",
                    "messages": [{"role": "user", "content": prompt_builder_query}],
                    "temperature": 0.3,
                    "response_format": {"type": "json_object"}
                }
            )
            if resp.status_code == 200:
                gen = json.loads(resp.json()["choices"][0]["message"]["content"])
                agent_name = gen.get("agent_name", agent_name)
                first_message = gen.get("first_message", first_message)
                system_prompt = gen.get("system_prompt", system_prompt)
    except Exception as e:
        logger.warning(f"Using fallback agent prompt template: {str(e)}")

    # 2. WhatsApp Follow-up message setup
    whatsapp_msg = (
        f"Namaste! Thank you for speaking with {wizard_in.company_name}.\n"
    )
    if wizard_in.whatsapp_followup_link:
        whatsapp_msg += f"Here is the official document/link you requested: {wizard_in.whatsapp_followup_link}\n"
    whatsapp_msg += "Feel free to reply to this chat if you have any questions!"

    # 3. Create the Agent
    agent = Agent(
        tenant_id=tenant.id,
        name=agent_name,
        system_prompt=system_prompt,
        first_message=first_message,
        voice_provider=wizard_in.voice_preference or "sarvam",
        voice_id="bulbul:v1" if wizard_in.voice_preference == "sarvam" else "sonic-multilingual",
        language=wizard_in.language or "hi-IN",
        post_call_whatsapp_enabled=True,
        whatsapp_followup_message=whatsapp_msg
    )
    db.add(agent)
    await db.flush()

    # 4. Attach Knowledge Base if provided
    if wizard_in.knowledge_raw_text:
        qa_pairs = await KnowledgeService.extract_voice_friendly_qa(
            raw_text=wizard_in.knowledge_raw_text,
            business_name=wizard_in.company_name
        )
        kdoc = KnowledgeDocument(
            tenant_id=tenant.id,
            agent_id=agent.id,
            title="Core Business Knowledge & FAQ",
            doc_type="TEXT",
            raw_content=wizard_in.knowledge_raw_text,
            structured_qa=qa_pairs
        )
        db.add(kdoc)

    await db.commit()
    await db.refresh(agent)

    # 5. Trigger Instant Test Call if phone number was provided
    if wizard_in.phone_number_for_test_call:
        clean_phone = wizard_in.phone_number_for_test_call.strip().replace(" ", "").replace("-", "")
        background_tasks.add_task(
            trigger_onboarding_verification_call,
            phone_number=clean_phone,
            agent_id=agent.id,
            tenant_id=tenant.id,
            company_name=wizard_in.company_name
        )

    return {
        "status": "completed",
        "message": "Onboarding completed successfully! Your AI agent and knowledge base are live.",
        "tenant_id": tenant.id,
        "agent": {
            "id": agent.id,
            "name": agent.name,
            "first_message": agent.first_message,
            "system_prompt": agent.system_prompt,
            "language": agent.language
        },
        "test_call_initiated": bool(wizard_in.phone_number_for_test_call)
    }
