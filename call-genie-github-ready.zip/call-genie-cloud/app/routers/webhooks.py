import logging
from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db, AsyncSessionLocal
from app.models import CallLog, Agent, Campaign, Contact
from app.services.billing_service import BillingService
from app.services.whatsapp_service import WhatsAppService
from app.services.webhook_dispatcher import WebhookDispatcherService

logger = logging.getLogger("webhooks")
router = APIRouter(prefix="/api/webhooks", tags=["Webhooks & Call Events"])


async def handle_post_call_background_tasks(
    call_log_id: str,
    tenant_id: str,
    agent_id: str,
    receiver_number: str,
    summary: str,
    sentiment: str,
    transcript: str,
    recording_url: str,
    duration_seconds: int,
    campaign_id: str = None,
    contact_id: str = None
):
    async with AsyncSessionLocal() as db:
        # 1. Billing calculation and wallet debit
        billing_info = await BillingService.process_call_billing(
            db=db,
            tenant_id=tenant_id,
            duration_seconds=duration_seconds,
            call_log_id=call_log_id
        )

        # Update call log with billing details
        log_stmt = select(CallLog).where(CallLog.id == call_log_id)
        call_log = (await db.execute(log_stmt)).scalar_one_or_none()
        if call_log:
            call_log.billable_minutes = billing_info["billable_minutes"]
            call_log.revenue_charged_inr = billing_info["revenue_charged_inr"]
            call_log.cost_incurred_inr = billing_info["cost_incurred_inr"]
            await db.commit()

        # 2. Update Campaign & Contact status if outbound
        if campaign_id and contact_id:
            c_stmt = select(Contact).where(Contact.id == contact_id)
            contact = (await db.execute(c_stmt)).scalar_one_or_none()
            if contact:
                contact.status = "ANSWERED" if duration_seconds > 5 else "BUSY"

            camp_stmt = select(Campaign).where(Campaign.id == campaign_id)
            campaign = (await db.execute(camp_stmt)).scalar_one_or_none()
            if campaign:
                campaign.completed_contacts += 1
                if duration_seconds > 5:
                    campaign.successful_calls += 1
                if campaign.completed_contacts >= campaign.total_contacts:
                    campaign.status = "COMPLETED"
            await db.commit()

        # 3. Post-Call WhatsApp Follow-Up (MyBot Genie)
        whatsapp_delivered = False
        if agent_id and receiver_number:
            agent_stmt = select(Agent).where(Agent.id == agent_id)
            agent = (await db.execute(agent_stmt)).scalar_one_or_none()

            if agent and agent.post_call_whatsapp_enabled:
                message_text = agent.whatsapp_followup_message
                if not message_text and summary:
                    message_text = (
                        f"Namaste! Thank you for speaking with our Call Genie AI assistant.\n\n"
                        f"Summary of our conversation:\n{summary}\n\n"
                        f"If you need any further assistance, feel free to reply directly to this WhatsApp message."
                    )

                whatsapp_delivered = await WhatsAppService.send_post_call_message(
                    phone_number=receiver_number,
                    message_text=message_text,
                    template_name=agent.whatsapp_template_name
                )

                if call_log:
                    call_log.whatsapp_status = "SENT" if whatsapp_delivered else "FAILED"
                    await db.commit()

        # 4. Dispatch Webhook Event to External Client CRM / Zapier / Pabbly Connect
        external_payload = {
            "call_id": call_log_id,
            "agent_id": agent_id,
            "receiver_number": receiver_number,
            "duration_seconds": duration_seconds,
            "billable_minutes": billing_info["billable_minutes"],
            "amount_charged_inr": billing_info["revenue_charged_inr"],
            "sentiment": sentiment,
            "summary": summary,
            "transcript": transcript,
            "recording_url": recording_url,
            "whatsapp_status": "SENT" if whatsapp_delivered else "NONE"
        }
        await WebhookDispatcherService.dispatch_call_event(
            tenant_id=tenant_id,
            event_type="call.completed",
            payload=external_payload
        )


@router.post("/call-ended")
async def call_ended_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    room_name = payload.get("room_name")
    duration_seconds = int(payload.get("duration_seconds", 0))
    transcript = payload.get("transcript", "")
    summary = payload.get("summary", "")
    sentiment = payload.get("sentiment", "NEUTRAL")
    recording_url = payload.get("recording_url")

    stmt = select(CallLog).where(CallLog.room_name == room_name)
    call_log = (await db.execute(stmt)).scalar_one_or_none()

    if not call_log:
        logger.warning(f"Webhook received for unknown room_name: {room_name}")
        return {"status": "ignored", "reason": "room_not_found"}

    call_log.duration_seconds = duration_seconds
    call_log.status = "COMPLETED" if duration_seconds > 0 else "NO_ANSWER"
    call_log.transcript = transcript
    call_log.summary = summary
    call_log.sentiment = sentiment
    call_log.recording_url = recording_url
    await db.commit()

    background_tasks.add_task(
        handle_post_call_background_tasks,
        call_log_id=call_log.id,
        tenant_id=call_log.tenant_id,
        agent_id=call_log.agent_id,
        receiver_number=call_log.receiver_number,
        summary=summary,
        sentiment=sentiment,
        transcript=transcript,
        recording_url=recording_url,
        duration_seconds=duration_seconds,
        campaign_id=call_log.campaign_id,
        contact_id=call_log.contact_id
    )

    return {"status": "success", "call_log_id": call_log.id}
