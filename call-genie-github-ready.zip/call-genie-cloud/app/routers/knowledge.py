from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime
from app.database import get_db
from app.models import Agent, KnowledgeDocument, User
from app.routers.auth import get_current_user
from app.services.knowledge_service import KnowledgeService

router = APIRouter(prefix="/api/agents", tags=["Knowledge Base & Voice RAG"])


class KnowledgeCreate(BaseModel):
    title: str
    content: str
    doc_type: Optional[str] = "TEXT"


class KnowledgeOut(BaseModel):
    id: str
    agent_id: str
    title: str
    doc_type: str
    raw_content: str
    structured_qa: list
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


@router.post("/{agent_id}/knowledge", response_model=KnowledgeOut)
async def add_knowledge_doc(
    agent_id: str,
    doc_in: KnowledgeCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    # Verify agent ownership
    stmt = select(Agent).where(Agent.id == agent_id, Agent.tenant_id == current_user.tenant_id)
    agent = (await db.execute(stmt)).scalar_one_or_none()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    # Extract voice-optimized Q&A using Groq
    qa_pairs = await KnowledgeService.extract_voice_friendly_qa(
        raw_text=doc_in.content,
        business_name=agent.name
    )

    doc = KnowledgeDocument(
        tenant_id=current_user.tenant_id,
        agent_id=agent.id,
        title=doc_in.title,
        doc_type=doc_in.doc_type or "TEXT",
        raw_content=doc_in.content,
        structured_qa=qa_pairs
    )
    db.add(doc)
    await db.commit()
    await db.refresh(doc)
    return doc


@router.post("/{agent_id}/knowledge/upload-file", response_model=KnowledgeOut)
async def upload_knowledge_file(
    agent_id: str,
    file: UploadFile = File(...),
    title: Optional[str] = Form(None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    stmt = select(Agent).where(Agent.id == agent_id, Agent.tenant_id == current_user.tenant_id)
    agent = (await db.execute(stmt)).scalar_one_or_none()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")

    content_bytes = await file.read()
    try:
        raw_text = content_bytes.decode("utf-8", errors="ignore")
    except Exception:
        raw_text = "Uploaded document content"

    doc_title = title or file.filename or "Uploaded Document"
    
    qa_pairs = await KnowledgeService.extract_voice_friendly_qa(
        raw_text=raw_text,
        business_name=agent.name
    )

    doc = KnowledgeDocument(
        tenant_id=current_user.tenant_id,
        agent_id=agent.id,
        title=doc_title,
        doc_type="PDF" if file.filename.endswith(".pdf") else "TEXT",
        raw_content=raw_text[:10000],
        structured_qa=qa_pairs
    )
    db.add(doc)
    await db.commit()
    await db.refresh(doc)
    return doc


@router.get("/{agent_id}/knowledge", response_model=List[KnowledgeOut])
async def list_agent_knowledge(
    agent_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    stmt = select(KnowledgeDocument).where(
        KnowledgeDocument.agent_id == agent_id,
        KnowledgeDocument.tenant_id == current_user.tenant_id
    ).order_by(KnowledgeDocument.created_at.desc())
    result = await db.execute(stmt)
    return result.scalars().all()


@router.delete("/{agent_id}/knowledge/{doc_id}")
async def delete_knowledge_doc(
    agent_id: str,
    doc_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    stmt = select(KnowledgeDocument).where(
        KnowledgeDocument.id == doc_id,
        KnowledgeDocument.agent_id == agent_id,
        KnowledgeDocument.tenant_id == current_user.tenant_id
    )
    doc = (await db.execute(stmt)).scalar_one_or_none()
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    await db.delete(doc)
    await db.commit()
    return {"message": "Knowledge document removed successfully"}
