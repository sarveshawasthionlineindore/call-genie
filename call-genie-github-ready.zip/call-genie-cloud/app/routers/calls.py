from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from typing import List, Optional
from app.database import get_db
from app.models import CallLog, User
from app.schemas import CallLogOut
from app.routers.auth import get_current_user

router = APIRouter(prefix="/api/calls", tags=["Call Logs & Analytics"])


@router.get("", response_model=List[CallLogOut])
async def list_call_logs(
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    status: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    stmt = select(CallLog).where(CallLog.tenant_id == current_user.tenant_id)
    if status:
        stmt = stmt.where(CallLog.status == status)
    stmt = stmt.order_by(desc(CallLog.created_at)).offset(offset).limit(limit)
    
    result = await db.execute(stmt)
    return result.scalars().all()


@router.get("/{call_id}", response_model=CallLogOut)
async def get_call_detail(
    call_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    stmt = select(CallLog).where(CallLog.id == call_id, CallLog.tenant_id == current_user.tenant_id)
    call_log = (await db.execute(stmt)).scalar_one_or_none()
    if not call_log:
        raise HTTPException(status_code=404, detail="Call record not found")
    return call_log
