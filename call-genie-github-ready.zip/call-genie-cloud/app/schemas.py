from pydantic import BaseModel, EmailStr
from typing import Optional, List, Dict, Any
from datetime import datetime


# Auth Schemas
class UserRegister(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    company_name: str


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    tenant_id: str
    email: str
    company_name: str


# Agent Schemas
class AgentCreate(BaseModel):
    name: str
    system_prompt: str
    first_message: str
    voice_provider: Optional[str] = "sarvam"
    voice_id: Optional[str] = "bulbul:v1"
    language: Optional[str] = "hi-IN"
    temperature: Optional[float] = 0.7
    inbound_phone_number: Optional[str] = None
    post_call_whatsapp_enabled: Optional[bool] = True
    whatsapp_template_name: Optional[str] = None
    whatsapp_followup_message: Optional[str] = None


class AgentUpdate(BaseModel):
    name: Optional[str] = None
    system_prompt: Optional[str] = None
    first_message: Optional[str] = None
    voice_provider: Optional[str] = None
    voice_id: Optional[str] = None
    language: Optional[str] = None
    temperature: Optional[float] = None
    inbound_phone_number: Optional[str] = None
    post_call_whatsapp_enabled: Optional[bool] = None
    whatsapp_template_name: Optional[str] = None
    whatsapp_followup_message: Optional[str] = None
    is_active: Optional[bool] = None


class AgentOut(BaseModel):
    id: str
    name: str
    system_prompt: str
    first_message: str
    voice_provider: str
    voice_id: str
    language: str
    temperature: float
    inbound_phone_number: Optional[str]
    post_call_whatsapp_enabled: bool
    whatsapp_followup_message: Optional[str]
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


# Campaign & Outbound Schemas
class CampaignCreate(BaseModel):
    name: str
    agent_id: str
    concurrency_limit: Optional[int] = 1


class ContactItem(BaseModel):
    phone_number: str
    name: Optional[str] = None
    custom_data: Optional[Dict[str, Any]] = None


class BatchContactsUpload(BaseModel):
    contacts: List[ContactItem]


class SingleCallRequest(BaseModel):
    agent_id: str
    phone_number: str
    customer_name: Optional[str] = None
    custom_variables: Optional[Dict[str, Any]] = None


# Wallet Schemas
class WalletOut(BaseModel):
    balance_inr: float
    currency: str
    rate_per_min_inr: float


class WalletRechargeRequest(BaseModel):
    amount_inr: float
    payment_reference: str  # Razorpay payment ID


class TransactionOut(BaseModel):
    id: str
    amount_inr: float
    type: str
    description: Optional[str]
    reference_id: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# Call Log Schemas
class CallLogOut(BaseModel):
    id: str
    room_name: str
    caller_number: Optional[str]
    receiver_number: Optional[str]
    direction: str
    duration_seconds: int
    billable_minutes: float
    revenue_charged_inr: float
    status: str
    recording_url: Optional[str]
    transcript: Optional[str]
    summary: Optional[str]
    sentiment: Optional[str]
    whatsapp_status: str
    created_at: datetime

    class Config:
        from_attributes = True
