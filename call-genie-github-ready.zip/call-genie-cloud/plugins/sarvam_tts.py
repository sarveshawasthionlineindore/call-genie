import os
import io
import base64
import httpx
import logging
from typing import Optional

logger = logging.getLogger("sarvam_tts")


class SarvamTTS:
    """
    Direct client for Sarvam AI Bulbul Text-to-Speech API.
    Provides natural Hindi and Indian English voice generation at ~₹0.70/min.
    """
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("SARVAM_API_KEY")
        self.api_url = "https://api.sarvam.ai/text-to-speech"

    async def synthesize(
        self,
        text: str,
        target_language_code: str = "hi-IN",
        speaker: str = "meera",
        sample_rate: int = 16000
    ) -> Optional[bytes]:
        if not self.api_key:
            logger.error("SARVAM_API_KEY is not configured.")
            return None

        headers = {
            "api-subscription-key": self.api_key,
            "Content-Type": "application/json"
        }

        payload = {
            "inputs": [text],
            "target_language_code": target_language_code,
            "speaker": speaker,
            "pitch": 0,
            "pace": 1.0,
            "loudness": 1.5,
            "speech_sample_rate": sample_rate,
            "enable_preprocessing": True,
            "model": "bulbul:v1"
        }

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(self.api_url, headers=headers, json=payload)
                if response.status_code == 200:
                    data = response.json()
                    audio_b64 = data.get("audios", [None])[0]
                    if audio_b64:
                        return base64.b64decode(audio_b64)
                else:
                    logger.error(f"Sarvam TTS error {response.status_code}: {response.text}")
                    return None
        except Exception as e:
            logger.error(f"Exception during Sarvam TTS synthesis: {str(e)}")
            return None
